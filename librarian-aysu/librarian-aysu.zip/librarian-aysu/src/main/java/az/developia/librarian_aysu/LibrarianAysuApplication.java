package az.developia.librarian_aysu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibrarianAysuApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibrarianAysuApplication.class, args);
	}

}
