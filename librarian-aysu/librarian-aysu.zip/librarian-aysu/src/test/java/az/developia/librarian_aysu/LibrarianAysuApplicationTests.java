package az.developia.librarian_aysu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrarianAysuApplicationTests {

	@Test
	void contextLoads() {
	}

}
